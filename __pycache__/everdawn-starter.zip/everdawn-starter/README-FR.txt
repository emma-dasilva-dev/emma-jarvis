EVERDAWN — PROJET DE DÉPART

1. Ouvre Godot.
2. Clique sur « Importer ».
3. Choisis le fichier : project.godot
4. Ouvre le projet « Everdawn ».
5. Clique sur ▶ en haut à droite.

CONTRÔLES
- ZQSD ou WASD : marcher
- Souris : tourner la caméra
- Échap : libérer la souris
- Clique dans la fenêtre du jeu : reprendre le contrôle de la caméra

CE QUI EST DÉJÀ FAIT
- personnage 3D
- collisions
- gravité
- caméra à la troisième personne
- sol
- lumière
- ciel
- arbre simple
- petit élément mystérieux

Tu peux casser ce projet sans stress : c'est justement un projet de départ.
