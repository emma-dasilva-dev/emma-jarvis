extends CharacterBody3D

@export var speed: float = 5.5
@export var acceleration: float = 12.0
@export var mouse_sensitivity: float = 0.0025

@onready var camera_pivot: Node3D = $CameraPivot

var gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")

func _ready() -> void:
    Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
        rotate_y(-event.relative.x * mouse_sensitivity)
        camera_pivot.rotate_x(-event.relative.y * mouse_sensitivity)
        camera_pivot.rotation.x = clamp(camera_pivot.rotation.x, deg_to_rad(-45.0), deg_to_rad(25.0))

    if event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
        Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

    if event is InputEventMouseButton and event.pressed and Input.mouse_mode == Input.MOUSE_MODE_VISIBLE:
        Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _physics_process(delta: float) -> void:
    var input_x := 0.0
    var input_z := 0.0

    # WASD + ZQSD support.
    if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_Q):
        input_x -= 1.0
    if Input.is_key_pressed(KEY_D):
        input_x += 1.0
    if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_Z):
        input_z -= 1.0
    if Input.is_key_pressed(KEY_S):
        input_z += 1.0

    var input_dir := Vector3(input_x, 0.0, input_z).normalized()
    var move_dir := (transform.basis * input_dir).normalized()

    velocity.x = move_toward(velocity.x, move_dir.x * speed, acceleration * delta)
    velocity.z = move_toward(velocity.z, move_dir.z * speed, acceleration * delta)

    if not is_on_floor():
        velocity.y -= gravity * delta
    else:
        velocity.y = 0.0

    move_and_slide()
